# learns a vocabulary distribution
# that is, not only the tokens in the vocab
# but also, their frequency (that's the distribution)
def tokenExtractor(sentences):
    # as an excercise, use nested list comprehension
    # to reduce the below lines into just one line
    tokens = []
    for sentence in sentences:
        words = addSpaces(sentence).split()
        for word in words:
            tokens.append(word)
    return tokens

import string # for string.punctuation

def addSpaces(sentence):
    '''
    Helper function for tokenizing
    Adds spaces around all punctuation
    so punctuation is captured as a token
    '''
    for char in string.punctuation:
        sentence = sentence.replace(char, " " + char + " ")
    return " ".join(sentence.split())
