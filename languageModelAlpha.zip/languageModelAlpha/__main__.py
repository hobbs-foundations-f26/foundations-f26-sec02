import argparse
from .tokenExtractor import tokenExtractor
from .sentGenerator import genSentence
def get_filename():
    parser = argparse.ArgumentParser(
        description="Generate a random sentence from a text file."
    )
    parser.add_argument(
        "-f", "--filename", 
        type=str,
        default="languageModelAlpha/fish.txt",
        help="Text file to use as the word bank.")
    parser.add_argument(
        "-n", "--numSentences", 
        type=int,
        default=1,
        help="Number of sentences to generate/print")
    args = parser.parse_args()
    return args.filename, args.numSentences

filename, numSentences = get_filename()
try:
    with open(filename, "r") as f:
        lines = f.readlines()
except FileNotFoundError:
    print('please enter a valid file name')
    exit()
except:
    print('something went wrong')
    exit()

vocab = tokenExtractor(lines)
sentence = ""
for _ in range(numSentences):
    sentence += genSentence(vocab)

print(sentence)







# the below is redunant, the above is sufficient
# def main():
#     filename = get_filename()

#     with open(filename, "r") as f:
#         lines = f.readlines()

#     vocab = tokenExtractor(lines)
#     sentence = genSentence(vocab)

#     print(sentence)

# if __name__ == "__main__":
#     main()