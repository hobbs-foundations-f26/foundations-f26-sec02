import argparse

from .tokenExtractor import tokenExtractor
from .sentGenerator import genSentence

def get_filename():
    parser = argparse.ArgumentParser(
        description="Generate a random sentence from a text file."
    )
    parser.add_argument(
        "-f", "--filename", 
        type=str,
        default="languageModelAlpha/fish.txt",
        help="Text file to use as the word bank.")
    args = parser.parse_args()
    return args.filename

def main():
    filename = get_filename()

    with open(filename, "r") as f:
        lines = f.readlines()

    vocab = tokenExtractor(lines)
    print(vocab)
    sentence = genSentence(vocab)

    print(sentence)

if __name__ == "__main__":
    main()