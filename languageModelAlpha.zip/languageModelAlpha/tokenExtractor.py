# learns a vocabulary distribution
# that is, not only the tokens in the vocab
# but also, their frequency (that's the distribution)
def tokenExtractor(sentences):
    # as an excercise, use nested list comprehension
    # to reduce the below lines into just one line
    tokens = []
    for sentence in sentences:
        words = sentence.split()
        for word in words:
            tokens.append(word)
    return tokens