# this file generates a sentence 
# according to a vocabulary distribution
# (more frequent words in the vocab will be more
# frequenct in the generated sentence)
import random

def genSentence(words):
    sentence = ""
    word = random.choice(words)
    while word != ".":
        sentence = sentence + word + " "
        word = random.choice(words)
    return sentence + "."